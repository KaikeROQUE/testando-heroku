# Validação de formulários com JavaScript
Formulário construído com HTML e CSS <br>
<hr>
<b>Aulas no YouTube:</b>
<ul>
  <li><a href="https://youtu.be/JgM2C9b12EU">Construção do Formulário</a></li>
  <li><a href="https://youtu.be/YcTkoIAi0Bg">Validação dos campos com JavaScript</a></li>
</ul>
